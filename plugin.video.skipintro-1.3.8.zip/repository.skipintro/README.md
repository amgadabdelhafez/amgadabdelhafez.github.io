# Skip Intro Repository

This repository contains the Skip Intro addon for Kodi.

## Current Version

### v1.3.8

For more details about the addon, please refer to the [Skip Intro Addon Repository](https://github.com/amgadabdelhafez/plugin.video.skipintro).
