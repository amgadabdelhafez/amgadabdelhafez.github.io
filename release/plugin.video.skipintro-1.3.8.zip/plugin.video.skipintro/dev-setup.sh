#!/bin/bash

# Exit on error
set -e

KODI_ADDON_PATH="$HOME/Library/Application Support/Kodi/addons/plugin.video.skipintro"

echo "Setting up development environment..."

# Remove existing addon if it exists
if [ -e "$KODI_ADDON_PATH" ]; then
    echo "Removing existing addon..."
    rm -rf "$KODI_ADDON_PATH"
fi

# Create symbolic link
echo "Creating symbolic link..."
ln -s "$(pwd)" "$KODI_ADDON_PATH"

echo "Development setup complete!"
echo "The addon is now linked to Kodi. Changes will be reflected immediately."
echo "Note: You may need to restart Kodi or reload the addon for some changes to take effect."
