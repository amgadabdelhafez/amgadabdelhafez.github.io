import requests
import subprocess
import json

# def get_chapters(file_path):
#     cmd = ["ffmpeg", "-i", file_path, "-f", "ffmetadata", "-"]
#     result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
#     return result.stdout.decode()

# file_path = "https://lax1-4.download.real-debrid.com/d/SSTAI4EETI7JW93/Friends.S05E03.The.One.Hundredth.2160p.UHD.Blu-ray.Remux.DV.HEVC.DTS-HD.MA.5.1-SiCFoI.mkv"
# chapters = get_chapters(file_path)
# print(chapters)

import requests
import subprocess
import json

def get_file_info():
    """
    Fetch file info using Kodi's JSON-RPC API.
    """
    url = "http://localhost:1984/jsonrpc"
    headers = {"Content-Type": "application/json"}
    payload = {
        "jsonrpc": "2.0",
        "method": "Player.GetItem",
        "params": {
            "playerid": 1,
            "properties": ["title", "duration", "file"]
        },
        "id": 1
    }
    response = requests.post(url, headers=headers, json=payload)
    
    # Check for error in the response
    if response.status_code != 200:
        print("Error: Unable to fetch data from Kodi API")
        return None
    
    # Parse the response and extract file information
    file_info = response.json()
    
    # Make sure response contains the file information
    if 'result' in file_info and 'item' in file_info['result']:
        return file_info['result']['item'].get("file", "No file found")
    else:
        print(f"Error: {file_info.get('error', 'Unknown error')}")
        return None


def get_chapters(file_path):
    cmd = ["ffmpeg", "-i", file_path, "-f", "ffmetadata", "-"]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout.decode()



def parse_ffmpeg_metadata(metadata):
    """
    Parse FFmpeg metadata to extract chapter information.
    
    Args:
        metadata (str): FFmpeg metadata output as a string.

    Returns:
        List[Dict]: A list of dictionaries containing chapter details.
    """
    chapters = []
    current_chapter = {}
    
    # Split metadata into lines
    for line in metadata.splitlines():
        if line.startswith("[CHAPTER]"):
            # If there is a current chapter, append it to the list and start a new one
            if current_chapter:
                chapters.append(current_chapter)
                current_chapter = {}
        elif line.startswith("START="):
            current_chapter["start"] = int(line.split("=")[1]) / 1e9  # Convert nanoseconds to seconds
        elif line.startswith("END="):
            current_chapter["end"] = int(line.split("=")[1]) / 1e9  # Convert nanoseconds to seconds
        elif line.startswith("title="):
            current_chapter["title"] = line.split("=")[1]
    
    # Append the last chapter if it exists
    if current_chapter:
        chapters.append(current_chapter)

    return chapters

# Example usage
file_path = get_file_info()
# file_path = "https://lax1-4.download.real-debrid.com/d/SSTAI4EETI7JW93/Friends.S05E03.The.One.Hundredth.2160p.UHD.Blu-ray.Remux.DV.HEVC.DTS-HD.MA.5.1-SiCFoI.mkv"


if file_path:
    print(f"File path: {file_path}")
else:
    print("Could not fetch file information")

metadata = get_chapters(file_path)
print(metadata)

chapters = parse_ffmpeg_metadata(metadata)
print(f"File: {file_path}")
print("Chapters:")

for chapter in chapters:
    # Ensure the chapter contains both 'start' and 'end' keys
    if 'start' in chapter and 'end' in chapter:
        print(f" - {chapter['title']}: Start={chapter['start']:.2f}s, End={chapter['end']:.2f}s")
    else:
        # This is the first entry, which contains only the 'title'
        print(f" - {chapter['title']}")
